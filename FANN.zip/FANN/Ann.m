
gain_ia_k=max(Ia_K);
gain_ua=max(Ua);
gain_wr=max (Wr_k);
k=length(time);
dt=10;
input_data=[(Ia_K(1:dt:k)./gain_ia_k)';(Ia_K_1(1:dt:k)./gain_ia_k)';(Ua(1:dt:k)./gain_ua)']; 
target=(Wr_k(1:dt:k)./gain_wr)';
net =newff([-1 1;-1 1;-1 1],[1 1],{'tansig','purelin'},'trainlm');
net=init(net);
net.trainParam.epochs = 10000; 
net.trainParam.goal=5e-5; 
net.trainParam.lr=5e-3; 
[net, tr]= train(net,input_data,target);
target_es=sim(net,input_data); 


figure;
plot(time(1:dt:k),target,'r',time(1:dt:k),target_es,'b'),grid
xlabel(' Time [Sec]','Fontsize',8)
ylabel('actual speed & speed estimated [rad/sec]','Fontsize',8)

WI=net.IW{1,1};
WL=net.LW{2,1};
BI=net.b{1,1};
BL=net.b{2,1};
